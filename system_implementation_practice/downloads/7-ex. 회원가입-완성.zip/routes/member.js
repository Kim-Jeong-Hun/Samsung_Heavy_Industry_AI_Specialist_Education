import express from 'express';
import pool from '../db.js';

const router = express.Router();

router.get('/form', (req, res) => {
  res.render('form');
});

router.post('/form', async (req, res) => {
  const { name, email } = req.body;

  try {
    const sql = 'INSERT INTO member (name, email) VALUES (?, ?)';
    const [result] = await pool.query(sql, [name, email]);
    res.render('result', { success: true, id: result.insertId });
  } catch (e) {
    console.error('회원 등록 실패:', e.message);
    res.render('result', { success: false });
  }
});

export default router;
